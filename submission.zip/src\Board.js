import React from 'react';
import Dragula from 'dragula';
import 'dragula/dist/dragula.css';
import Swimlane from './Swimlane';
import './Board.css';

export default class Board extends React.Component {
  constructor(props) {
    super(props);
    
    // load from localStorage or get defaults
    let clients = [];
    const saved = localStorage.getItem('shiptivitas-tasks');
    if (saved) {
      clients = JSON.parse(saved);
    } else {
      clients = this.getClients();
      localStorage.setItem('shiptivitas-tasks', JSON.stringify(clients));
    }
    this.clientsList = clients; // keep a flat list for easy updates
    
    this.state = {
      clients: {
        backlog: clients.filter(client => !client.status || client.status === 'backlog'),
        inProgress: clients.filter(client => client.status && client.status === 'in-progress'),
        complete: clients.filter(client => client.status && client.status === 'complete'),
      }
    }
    
    // tracking the column elements for dragula
    this.laneRefs = {
      backlog: React.createRef(),
      inProgress: React.createRef(),
      complete: React.createRef(),
    }
  }
  componentDidMount() {
    // initialize drag and drop
    this.drake = Dragula([
      this.laneRefs.backlog.current,
      this.laneRefs.inProgress.current,
      this.laneRefs.complete.current,
    ]);

    // what happens when we drop a card
    this.drake.on('drop', (el, target, source, sibling) => {
      let targetClass = '';
      let targetStatus = '';
      
      // figure out which lane it was dropped into
      if (target === this.laneRefs.backlog.current) {
        targetClass = 'Card-grey';
        targetStatus = 'backlog';
      } else if (target === this.laneRefs.inProgress.current) {
        targetClass = 'Card-blue';
        targetStatus = 'in-progress';
      } else if (target === this.laneRefs.complete.current) {
        targetClass = 'Card-green';
        targetStatus = 'complete';
      }
      
      // update the card styles
      el.className = `Card ${targetClass}`;
      el.dataset.status = targetStatus;
      
      // update local storage so HomeTab can see the changes
      const clientId = el.dataset.id;
      const client = this.clientsList.find(c => String(c.id) === String(clientId));
      if (client) {
        client.status = targetStatus;
        localStorage.setItem('shiptivitas-tasks', JSON.stringify(this.clientsList));
      }
    });
  }
  
  componentWillUnmount() {
    if (this.drake) {
      this.drake.destroy();
    }
  }
  getClients() {
    return [
      ['1','Stark, White and Abbott','Cloned Optimal Architecture', 'in-progress'],
      ['2','Wiza LLC','Exclusive Bandwidth-Monitored Implementation', 'complete'],
      ['3','Nolan LLC','Vision-Oriented 4Thgeneration Graphicaluserinterface', 'backlog'],
      ['4','Thompson PLC','Streamlined Regional Knowledgeuser', 'in-progress'],
      ['5','Walker-Williamson','Team-Oriented 6Thgeneration Matrix', 'in-progress'],
      ['6','Boehm and Sons','Automated Systematic Paradigm', 'backlog'],
      ['7','Runolfsson, Hegmann and Block','Integrated Transitional Strategy', 'backlog'],
      ['8','Schumm-Labadie','Operative Heuristic Challenge', 'backlog'],
      ['9','Kohler Group','Re-Contextualized Multi-Tasking Attitude', 'backlog'],
      ['10','Romaguera Inc','Managed Foreground Toolset', 'backlog'],
      ['11','Reilly-King','Future-Proofed Interactive Toolset', 'complete'],
      ['12','Emard, Champlin and Runolfsdottir','Devolved Needs-Based Capability', 'backlog'],
      ['13','Fritsch, Cronin and Wolff','Open-Source 3Rdgeneration Website', 'complete'],
      ['14','Borer LLC','Profit-Focused Incremental Orchestration', 'backlog'],
      ['15','Emmerich-Ankunding','User-Centric Stable Extranet', 'in-progress'],
      ['16','Willms-Abbott','Progressive Bandwidth-Monitored Access', 'in-progress'],
      ['17','Brekke PLC','Intuitive User-Facing Customerloyalty', 'complete'],
      ['18','Bins, Toy and Klocko','Integrated Assymetric Software', 'backlog'],
      ['19','Hodkiewicz-Hayes','Programmable Systematic Securedline', 'backlog'],
      ['20','Murphy, Lang and Ferry','Organized Explicit Access', 'backlog'],
    ].map(clientData => ({
      id: clientData[0],
      name: clientData[1],
      description: clientData[2],
      status: clientData[3] || 'backlog', // use default status from array
    }));
  }
  
  // helper to render the columns
  renderSwimlane(name, clients, ref) {
    return (
      <Swimlane name={name} clients={clients} dragulaRef={ref}/>
    );
  }

  render() {
    return (
      <div className="Board">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-4">
              {this.renderSwimlane('Backlog', this.state.clients.backlog, this.laneRefs.backlog)}
            </div>
            <div className="col-md-4">
              {this.renderSwimlane('In Progress', this.state.clients.inProgress, this.laneRefs.inProgress)}
            </div>
            <div className="col-md-4">
              {this.renderSwimlane('Complete', this.state.clients.complete, this.laneRefs.complete)}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
